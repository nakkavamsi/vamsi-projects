package com.homescreenarcade.pinball;

/** Simple class to hold a message displayed in the ScoreView above the game field.
 */

public class GameMessage {
	public String text;
	public long duration;
	public long creationTime;
}
